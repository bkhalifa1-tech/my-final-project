package com.example.myfinalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.databinding.ItemNumberBinding;

import java.util.ArrayList;

public class numberAdapter extends RecyclerView.Adapter<numberAdapter.NumberViewHolder> {
ArrayList<numbers> num;

    public numberAdapter(ArrayList<numbers> num) {
        this.num = num;
    }

    @NonNull
    @Override
    public NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                ItemNumberBinding binding=ItemNumberBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
                return new NumberViewHolder(binding);
    }

    @Override
    public int getItemCount() {
        return num.size();
    }

    @Override
    public void onBindViewHolder(@NonNull NumberViewHolder holder, int position) {
numbers number = num.get(position);
holder.numberPhoneTv.setText(number.getNumber());
holder.numberNameTv.setText(number.getName());
    }

    public static class NumberViewHolder extends RecyclerView.ViewHolder{
    TextView numberNameTv , numberPhoneTv;
        public NumberViewHolder(@NonNull ItemNumberBinding binding) {
            super(binding.getRoot());
            numberNameTv=binding.numberNameTv;
            numberPhoneTv=binding.numberPhoneTv;
        }
    }
}
