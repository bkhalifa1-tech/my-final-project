package com.example.myfinalproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "pregnancy_app.db";
    private static final int DB_VERSION = 2;

    // USERS TABLE
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id";
    public static final String COL_USER_NAME = "full_name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD = "password";
    public static final String COL_USER_PHONE = "phone";
    public static final String COL_USER_LAST_PERIOD = "last_period_date";
    public static final String COL_USER_DUE_DATE = "due_date";


    // APPOINTMENTS TABLE

    public static final String TABLE_APPOINTMENTS = "appointments";
    public static final String COL_APP_ID = "_id";
    public static final String COL_APP_USER_EMAIL = "user_email";
    public static final String COL_APP_SUBJECT = "subject";
    public static final String COL_APP_DOCTOR = "doctor";
    public static final String COL_APP_DATE = "app_date";
    public static final String COL_APP_TIME = "app_time";
    public static final String COL_APP_LOCATION = "location";
    public static final String COL_APP_PHONE = "phone";

    // CONTACTS TABLE
    public static final String TABLE_CONTACTS = "contacts";
    public static final String COL_CONTACT_ID = "_id";
    public static final String COL_CONTACT_USER_EMAIL = "user_email";
    public static final String COL_CONTACT_NAME = "name";
    public static final String COL_CONTACT_PHONE = "phone";

    // FETAL DEVELOPMENT TABLE
    public static final String TABLE_FETAL = "fetal_development";
    public static final String COL_FETAL_WEEK = "week_number";
    public static final String COL_FETAL_TITLE = "title";
    public static final String COL_FETAL_DESC = "description";
    public static final String COL_FETAL_TIP_ONE = "tip_one";
    public static final String COL_FETAL_TIP_TWO = "tip_two";
    public static final String COL_FETAL_TIP_THREE = "tip_three";

    public MyDatabaseHelper(@Nullable Context context ) {
        super(context, "pregnancy_app.db", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        createUsersTable(db);
        createAppointmentsTable(db);
        createContactsTable(db);
        createFetalDevelopmentTable(db);
        // تعبئة جدول تطور الحمل من الأسبوع 1 إلى 40
//        seedFetalDevelopmentData(db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
         private void createUsersTable(SQLiteDatabase db) {
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USER_NAME +
                        " TEXT NOT NULL, " +
                        COL_USER_EMAIL +
                        " TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        COL_USER_PASSWORD +
                        " TEXT NOT NULL, " +
                        COL_USER_PHONE +
                        " TEXT, " +
                        COL_USER_LAST_PERIOD +
                        " TEXT, " +
                        COL_USER_DUE_DATE +
                        " TEXT" + ")";
        db.execSQL(createUsersTable);
    }

    // CREATE APPOINTMENTS TABLE
    private void createAppointmentsTable(SQLiteDatabase db) {

        String createAppointmentsTable =
                "CREATE TABLE " + TABLE_APPOINTMENTS + " (" +
                        COL_APP_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_APP_USER_EMAIL +
                        " TEXT NOT NULL, " +
                        COL_APP_SUBJECT +
                        " TEXT NOT NULL, " +
                        COL_APP_DOCTOR +
                        " TEXT, " +
                        COL_APP_DATE +
                        " TEXT, " +
                        COL_APP_TIME +
                        " TEXT, " +
                        COL_APP_LOCATION +
                        " TEXT, " +
                        COL_APP_PHONE +
                        " TEXT, " +
                        "FOREIGN KEY(" +
                        COL_APP_USER_EMAIL +
                        ") REFERENCES " +
                        TABLE_USERS +
                        "(" +
                        COL_USER_EMAIL +
                        ") ON DELETE CASCADE" + ")";
        db.execSQL(createAppointmentsTable);
    }
    // CREATE CONTACTS TABLE
    private void createContactsTable(SQLiteDatabase db) {

        String createContactsTable =
                "CREATE TABLE " + TABLE_CONTACTS + " (" +
                        COL_CONTACT_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_CONTACT_USER_EMAIL +
                        " TEXT NOT NULL, " +
                        COL_CONTACT_NAME +
                        " TEXT NOT NULL, " +
                        COL_CONTACT_PHONE +
                        " TEXT NOT NULL, " +
                        "FOREIGN KEY(" +
                        COL_CONTACT_USER_EMAIL +
                        ") REFERENCES " +
                        TABLE_USERS +
                        "(" +
                        COL_USER_EMAIL +
                        ") ON DELETE CASCADE" + ")";
        db.execSQL(createContactsTable);
    }

    // CREATE FETAL DEVELOPMENT TABLE
    private void createFetalDevelopmentTable(SQLiteDatabase db) {

        String createFetalTable =
                "CREATE TABLE " + TABLE_FETAL + " (" +
                        COL_FETAL_WEEK +
                        " INTEGER PRIMARY KEY, " +
                        COL_FETAL_TITLE +
                        " TEXT NOT NULL, " +
                        COL_FETAL_DESC +
                        " TEXT NOT NULL, " +
                        COL_FETAL_TIP_ONE +
                        " TEXT NOT NULL, " +
                        COL_FETAL_TIP_TWO +
                        " TEXT NOT NULL, " +
                        COL_FETAL_TIP_THREE +
                        " TEXT NOT NULL" + ")";
        db.execSQL(createFetalTable);
    }
}
