package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myfinalproject.databinding.ActivityProfileBinding;


public class ProfileActivity extends AppCompatActivity {

    ActivityProfileBinding binding;

    ActivityResultLauncher<Intent> launcher=registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if(o.getResultCode()==RESULT_OK){
                        Intent resultIntent=o.getData();
                    binding.tvProfileName.setText(resultIntent.getStringExtra("Name"));
                    binding.tvPhoneValueRow.setText(resultIntent.getStringExtra("phone"));
                    binding.tvDateValue.setText(resultIntent.getStringExtra("formattedDate"));
                    }

                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Intent intent_Register=getIntent();
        binding.tvEmailValueRow.setText( intent_Register.getStringExtra("email"));
        binding.tvProfileName.setText(intent_Register.getStringExtra("Name"));
        binding.tvPhoneValueRow.setText(  intent_Register.getStringExtra("phone"));
        binding.tvDateValue.setText( intent_Register.getStringExtra("formattedDate"));


        binding.btnEditAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(ProfileActivity.this,EditProfileActivity.class);
                launcher.launch(intent);
            }
        });

    }
}
