package com.example.myfinalproject;

import java.util.Arrays;
import java.util.List;

public class FetalWeek {

    private int weekNumber;
    private String title;
    private String description;
    private String tipOne;
    private String tipTwo;
    private String tipThree;

    public FetalWeek(int weekNumber, String title, String description,
                     String tipOne, String tipTwo, String tipThree) {
        this.weekNumber = weekNumber;
        this.title = title;
        this.description = description;
        this.tipOne = tipOne;
        this.tipTwo = tipTwo;
        this.tipThree = tipThree;
    }

    public int getWeekNumber() {
        return weekNumber;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getTips() {
        return Arrays.asList(tipOne, tipTwo, tipThree);
    }
}
