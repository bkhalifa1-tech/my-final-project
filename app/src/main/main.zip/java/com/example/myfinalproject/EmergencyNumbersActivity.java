package com.example.myfinalproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.PackdgeRecyclerNumber.numberAdapter;
import com.example.myfinalproject.PackdgeRecyclerNumber.numbers;
import com.example.myfinalproject.databinding.ActivityEmergencyNumbersBinding;
import com.example.myfinalproject.databinding.ActivityLoginBinding;

import java.util.ArrayList;
import java.util.List;

public class EmergencyNumbersActivity extends AppCompatActivity {

    ActivityEmergencyNumbersBinding binding;

    ArrayList<numbers> numbers;
    


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEmergencyNumbersBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        numbers = new ArrayList<>();
            numbers.add(new numbers(1,"banan","0567447041"));
            numbers.add(new numbers(2,"baraa","0564444444"));
            numbers.add(new numbers(3,"yehia","0563333333"));
            numberAdapter numberAdapter=new numberAdapter(numbers);
            binding.rvEmergency.setAdapter(numberAdapter);

            RecyclerView.LayoutManager lm=new LinearLayoutManager(
                    EmergencyNumbersActivity.this,LinearLayoutManager.VERTICAL ,false);

            binding.rvEmergency.setLayoutManager(lm);

            binding.btnSaveContact.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String ContactName=binding.etContactName.getText().toString();
                    String PhoneNumber=binding.etPhoneNumber.getText().toString();
                    numbers number=new numbers(ContactName,PhoneNumber);
                    numbers.add(number);
                    numberAdapter.notifyItemInserted(numbers.size());

                }
            });
    }
}
