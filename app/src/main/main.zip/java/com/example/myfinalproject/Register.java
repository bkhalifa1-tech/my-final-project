package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfinalproject.databinding.ActivityLoginBinding;
import com.example.myfinalproject.databinding.ActivityRegisterBinding;

public class Register extends AppCompatActivity {

    ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        DatabaseHelper databaseHelper =
                DatabaseHelper.getInstance(this);

        binding.tvCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Register.this, Login.class);
                startActivity(intent);
            }
        });
        binding.btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = binding.edFullName.getText().toString();
                String  password= binding.edPassword.getText().toString();
                String  ConfirmPassword= binding.edConfirmPassword.getText().toString();
                String email = binding.edEmail.getText().toString();
                String phone = binding.edPhone.getText().toString();

                if (Name.isEmpty() || ConfirmPassword.isEmpty()||password.isEmpty() || email.isEmpty()|| phone.isEmpty()) {
                    Toast.makeText(Register.this, "يبدو أنك نسيت إدخال  بياناتك, يرجى إدخال بياناتك للمتابعة", Toast.LENGTH_SHORT).show();
                    return;
                }  if ( email.isEmpty()) {
                    Toast.makeText(Register.this, "يرجى إدخال [البريد الإلكتروني] الخاص بك لتسجيل الدخول", Toast.LENGTH_SHORT).show();
                    return;
                }  if (password.isEmpty() ) {
                    Toast.makeText(Register.this, "حقل [كلمة المرور] فارغ، يرجى إدخال كلمة المرور الصحيحة", Toast.LENGTH_SHORT).show();
                    return;
                } if (password.length()<6 ) {
                    Toast.makeText(Register.this, " يرجى إدخال كلمة المرور صحيحة", Toast.LENGTH_SHORT).show();
                    return;
                }if (!email.contains("@")) {
                    Toast.makeText(Register.this, " يرجى إدخال البريد الإلكتروني صحيح", Toast.LENGTH_SHORT).show();
                    return;
                }if (!ConfirmPassword.equals(password)) {
                    Toast.makeText(Register.this, " يرجى إدخال تأكيد  كلمة المرور ", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean registered = databaseHelper.registerUser(
                        Name,
                        email,
                        password,
                        phone
                );

                if (!registered) {
                    Toast.makeText(
                            Register.this,
                            "البريد الإلكتروني مسجل مسبقاً",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                Intent intent = new Intent(
                        Register.this,
                        Login.class
                );

                intent.putExtra("registered_email", email);
                startActivity(intent);
                finish();


            }

        });
    }
}
