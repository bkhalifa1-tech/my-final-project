package com.example.myfinalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.myfinalproject.PackdgeRecyclerNumber.numbers;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    // =========================================================
    // DATABASE INFORMATION
    // =========================================================

    private static final String DB_NAME = "pregnancy_app.db";

    // استخدمنا الإصدار 2 لأننا أضفنا last_period_date والنصائح
    private static final int DB_VERSION = 2;


    // =========================================================
    // USERS TABLE
    // =========================================================

    public static final String TABLE_USERS = "users";

    public static final String COL_USER_ID = "_id";
    public static final String COL_USER_NAME = "full_name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD = "password";
    public static final String COL_USER_PHONE = "phone";
    public static final String COL_USER_LAST_PERIOD = "last_period_date";
    public static final String COL_USER_DUE_DATE = "due_date";


    // =========================================================
    // APPOINTMENTS TABLE
    // =========================================================

    public static final String TABLE_APPOINTMENTS = "appointments";

    public static final String COL_APP_ID = "_id";
    public static final String COL_APP_USER_EMAIL = "user_email";
    public static final String COL_APP_SUBJECT = "subject";
    public static final String COL_APP_DOCTOR = "doctor";
    public static final String COL_APP_DATE = "app_date";
    public static final String COL_APP_TIME = "app_time";
    public static final String COL_APP_LOCATION = "location";
    public static final String COL_APP_PHONE = "phone";


    // =========================================================
    // CONTACTS TABLE
    // =========================================================

    public static final String TABLE_CONTACTS = "contacts";

    public static final String COL_CONTACT_ID = "_id";
    public static final String COL_CONTACT_USER_EMAIL = "user_email";
    public static final String COL_CONTACT_NAME = "name";
    public static final String COL_CONTACT_PHONE = "phone";


    // =========================================================
    // FETAL DEVELOPMENT TABLE
    // =========================================================

    public static final String TABLE_FETAL = "fetal_development";

    public static final String COL_FETAL_WEEK = "week_number";
    public static final String COL_FETAL_TITLE = "title";
    public static final String COL_FETAL_DESC = "description";
    public static final String COL_FETAL_TIP_ONE = "tip_one";
    public static final String COL_FETAL_TIP_TWO = "tip_two";
    public static final String COL_FETAL_TIP_THREE = "tip_three";


    // =========================================================
    // SINGLETON
    // =========================================================

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {

        if (instance == null) {

            instance = new DatabaseHelper(
                    context.getApplicationContext()
            );
        }

        return instance;
    }


    // Constructor خاص حتى نستخدم getInstance فقط

    private DatabaseHelper(Context context) {

        super(context, DB_NAME, null, DB_VERSION);
    }


    // =========================================================
    // ENABLE FOREIGN KEYS
    // =========================================================

    @Override
    public void onConfigure(SQLiteDatabase db) {

        super.onConfigure(db);

        // تشغيل العلاقات بين الجداول
        db.setForeignKeyConstraintsEnabled(true);
    }


    // =========================================================
    // CREATE TABLES
    // =========================================================

    @Override
    public void onCreate(SQLiteDatabase db) {

        createUsersTable(db);

        createAppointmentsTable(db);

        createContactsTable(db);

        createFetalDevelopmentTable(db);

        // تعبئة جدول تطور الحمل من الأسبوع 1 إلى 40
        seedFetalDevelopmentData(db);
    }




    // =========================================================
    // CREATE USERS TABLE
    // =========================================================

    private void createUsersTable(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +

                        COL_USER_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        COL_USER_NAME +
                        " TEXT NOT NULL, " +

                        COL_USER_EMAIL +
                        " TEXT NOT NULL UNIQUE COLLATE NOCASE, " +

                        COL_USER_PASSWORD +
                        " TEXT NOT NULL, " +

                        COL_USER_PHONE +
                        " TEXT, " +

                        COL_USER_LAST_PERIOD +
                        " TEXT, " +

                        COL_USER_DUE_DATE +
                        " TEXT" +

                        ")";

        db.execSQL(createUsersTable);
    }


    // =========================================================
    // CREATE APPOINTMENTS TABLE
    // =========================================================

    private void createAppointmentsTable(SQLiteDatabase db) {

        String createAppointmentsTable =
                "CREATE TABLE " + TABLE_APPOINTMENTS + " (" +

                        COL_APP_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        COL_APP_USER_EMAIL +
                        " TEXT NOT NULL, " +

                        COL_APP_SUBJECT +
                        " TEXT NOT NULL, " +

                        COL_APP_DOCTOR +
                        " TEXT, " +

                        COL_APP_DATE +
                        " TEXT, " +

                        COL_APP_TIME +
                        " TEXT, " +

                        COL_APP_LOCATION +
                        " TEXT, " +

                        COL_APP_PHONE +
                        " TEXT, " +

                        "FOREIGN KEY(" +
                        COL_APP_USER_EMAIL +
                        ") REFERENCES " +
                        TABLE_USERS +
                        "(" +
                        COL_USER_EMAIL +
                        ") ON DELETE CASCADE" +

                        ")";

        db.execSQL(createAppointmentsTable);
    }


    // =========================================================
    // CREATE CONTACTS TABLE
    // =========================================================

    private void createContactsTable(SQLiteDatabase db) {

        String createContactsTable =
                "CREATE TABLE " + TABLE_CONTACTS + " (" +

                        COL_CONTACT_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        COL_CONTACT_USER_EMAIL +
                        " TEXT NOT NULL, " +

                        COL_CONTACT_NAME +
                        " TEXT NOT NULL, " +

                        COL_CONTACT_PHONE +
                        " TEXT NOT NULL, " +

                        "FOREIGN KEY(" +
                        COL_CONTACT_USER_EMAIL +
                        ") REFERENCES " +
                        TABLE_USERS +
                        "(" +
                        COL_USER_EMAIL +
                        ") ON DELETE CASCADE" +

                        ")";

        db.execSQL(createContactsTable);
    }


    // =========================================================
    // CREATE FETAL DEVELOPMENT TABLE
    // =========================================================

    private void createFetalDevelopmentTable(SQLiteDatabase db) {

        String createFetalTable =
                "CREATE TABLE " + TABLE_FETAL + " (" +

                        COL_FETAL_WEEK +
                        " INTEGER PRIMARY KEY, " +

                        COL_FETAL_TITLE +
                        " TEXT NOT NULL, " +

                        COL_FETAL_DESC +
                        " TEXT NOT NULL, " +

                        COL_FETAL_TIP_ONE +
                        " TEXT NOT NULL, " +

                        COL_FETAL_TIP_TWO +
                        " TEXT NOT NULL, " +

                        COL_FETAL_TIP_THREE +
                        " TEXT NOT NULL" +

                        ")";

        db.execSQL(createFetalTable);
    }


    // =========================================================
    // DATABASE UPGRADE
    // =========================================================

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        /*
         * نحذف الجداول التابعة أولاً
         * ثم نحذف جدول المستخدمين.
         */

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        TABLE_APPOINTMENTS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        TABLE_CONTACTS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        TABLE_FETAL
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        TABLE_USERS
        );

        onCreate(db);
    }


    // =========================================================
    // USERS: REGISTER
    // =========================================================

    public boolean registerUser(
            String fullName,
            String email,
            String password,
            String phone
    ) {

        String normalizedEmail = normalizeEmail(email);

        // التأكد أن الإيميل غير مسجل سابقاً
        if (getUserByEmail(normalizedEmail) != null) {

            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(
                COL_USER_NAME,
                fullName.trim()
        );

        values.put(
                COL_USER_EMAIL,
                normalizedEmail
        );

        values.put(
                COL_USER_PASSWORD,
                password
        );

        values.put(
                COL_USER_PHONE,
                phone.trim()
        );

        long result = db.insert(
                TABLE_USERS,
                null,
                values
        );

        return result != -1;
    }


    // =========================================================
    // USERS: LOGIN
    // =========================================================

    @Nullable
    public User checkLogin(
            String email,
            String password
    ) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                null,

                COL_USER_EMAIL + "=? AND " +
                        COL_USER_PASSWORD + "=?",

                new String[]{
                        normalizeEmail(email),
                        password
                },

                null,
                null,
                null
        );

        User user = null;

        if (cursor.moveToFirst()) {

            user = userFromCursor(cursor);
        }

        cursor.close();

        return user;
    }


    // =========================================================
    // USERS: GET USER BY EMAIL
    // =========================================================

    @Nullable
    public User getUserByEmail(String email) {

        if (email == null) {

            return null;
        }

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                null,

                COL_USER_EMAIL + "=?",

                new String[]{
                        normalizeEmail(email)
                },

                null,
                null,
                null
        );

        User user = null;

        if (cursor.moveToFirst()) {

            user = userFromCursor(cursor);
        }

        cursor.close();

        return user;
    }


    // =========================================================
    // USERS: UPDATE PROFILE
    // =========================================================

    public boolean updateUser(User user) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(
                COL_USER_NAME,
                user.getFullName()
        );

        values.put(
                COL_USER_PHONE,
                user.getPhone()
        );

        values.put(
                COL_USER_LAST_PERIOD,
                user.getLastPeriodDate()
        );

        values.put(
                COL_USER_DUE_DATE,
                user.getDueDate()
        );

        int rows = db.update(
                TABLE_USERS,
                values,

                COL_USER_EMAIL + "=?",

                new String[]{
                        normalizeEmail(user.getEmail())
                }
        );

        return rows > 0;
    }


    // =========================================================
    // USERS: UPDATE PASSWORD
    // =========================================================

    public boolean updatePassword(
            String email,
            String newPassword
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(
                COL_USER_PASSWORD,
                newPassword
        );

        int rows = db.update(
                TABLE_USERS,
                values,

                COL_USER_EMAIL + "=?",

                new String[]{
                        normalizeEmail(email)
                }
        );

        return rows > 0;
    }


    // =========================================================
    // CONVERT CURSOR TO USER
    // =========================================================

    private User userFromCursor(Cursor cursor) {

        User user = new User();

        user.setId(
                cursor.getLong(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_ID
                        )
                )
        );

        user.setFullName(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_NAME
                        )
                )
        );

        user.setEmail(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_EMAIL
                        )
                )
        );

        user.setPassword(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_PASSWORD
                        )
                )
        );

        user.setPhone(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_PHONE
                        )
                )
        );

        user.setLastPeriodDate(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_LAST_PERIOD
                        )
                )
        );

        user.setDueDate(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_USER_DUE_DATE
                        )
                )
        );

        return user;
    }


    // =========================================================
    // APPOINTMENTS: ADD
    // =========================================================

    public long addAppointment(
            Appointment appointment
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values =
                appointmentToValues(appointment);

        return db.insert(
                TABLE_APPOINTMENTS,
                null,
                values
        );
    }


    // =========================================================
    // APPOINTMENTS: UPDATE
    // =========================================================

    public boolean updateAppointment(
            Appointment appointment
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values =
                appointmentToValues(appointment);

        int rows = db.update(
                TABLE_APPOINTMENTS,
                values,

                COL_APP_ID + "=? AND " +
                        COL_APP_USER_EMAIL + "=?",

                new String[]{
                        String.valueOf(
                                appointment.getId()
                        ),

                        normalizeEmail(
                                appointment.getUserEmail()
                        )
                }
        );

        return rows > 0;
    }


    // =========================================================
    // APPOINTMENTS: DELETE
    // =========================================================

    public boolean deleteAppointment(
            long appointmentId,
            String userEmail
    ) {

        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(
                TABLE_APPOINTMENTS,

                COL_APP_ID + "=? AND " +
                        COL_APP_USER_EMAIL + "=?",

                new String[]{
                        String.valueOf(appointmentId),
                        normalizeEmail(userEmail)
                }
        );

        return rows > 0;
    }


    // =========================================================
    // APPOINTMENTS: GET ONE APPOINTMENT
    // =========================================================

    @Nullable
    public Appointment getAppointmentById(
            long appointmentId,
            String userEmail
    ) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_APPOINTMENTS,
                null,

                COL_APP_ID + "=? AND " +
                        COL_APP_USER_EMAIL + "=?",

                new String[]{
                        String.valueOf(appointmentId),
                        normalizeEmail(userEmail)
                },

                null,
                null,
                null
        );

        Appointment appointment = null;

        if (cursor.moveToFirst()) {

            appointment =
                    appointmentFromCursor(cursor);
        }

        cursor.close();

        return appointment;
    }


    // =========================================================
    // APPOINTMENTS: GET ALL USER APPOINTMENTS
    // =========================================================

    public List<Appointment> getAppointmentsForUser(
            String userEmail
    ) {

        List<Appointment> list =
                new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_APPOINTMENTS,
                null,

                COL_APP_USER_EMAIL + "=?",

                new String[]{
                        normalizeEmail(userEmail)
                },

                null,
                null,

                COL_APP_DATE + " ASC, " +
                        COL_APP_TIME + " ASC"
        );

        while (cursor.moveToNext()) {

            list.add(
                    appointmentFromCursor(cursor)
            );
        }

        cursor.close();

        return list;
    }


    // =========================================================
    // APPOINTMENTS: CONVERT TO CONTENT VALUES
    // =========================================================

    private ContentValues appointmentToValues(
            Appointment appointment
    ) {

        ContentValues values =
                new ContentValues();

        values.put(
                COL_APP_USER_EMAIL,
                normalizeEmail(
                        appointment.getUserEmail()
                )
        );

        values.put(
                COL_APP_SUBJECT,
                appointment.getSubject()
        );

        values.put(
                COL_APP_DOCTOR,
                appointment.getDoctor()
        );

        values.put(
                COL_APP_DATE,
                appointment.getDate()
        );

        values.put(
                COL_APP_TIME,
                appointment.getTime()
        );

        values.put(
                COL_APP_LOCATION,
                appointment.getLocation()
        );

        values.put(
                COL_APP_PHONE,
                appointment.getPhone()
        );

        return values;
    }


    // =========================================================
    // APPOINTMENTS: CONVERT CURSOR TO APPOINTMENT
    // =========================================================

    private Appointment appointmentFromCursor(
            Cursor cursor
    ) {

        Appointment appointment =
                new Appointment();

        appointment.setId(
                Math.toIntExact(cursor.getLong(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_ID
                        )
                ))
        );

        appointment.setUserEmail(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_USER_EMAIL
                        )
                )
        );

        appointment.setSubject(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_SUBJECT
                        )
                )
        );

        appointment.setDoctor(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_DOCTOR
                        )
                )
        );

        appointment.setDate(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_DATE
                        )
                )
        );

        appointment.setTime(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_TIME
                        )
                )
        );

        appointment.setLocation(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_LOCATION
                        )
                )
        );

        appointment.setPhone(
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_APP_PHONE
                        )
                )
        );

        return appointment;
    }


    // =========================================================
    // CONTACTS: ADD
    // =========================================================

    public long addContact(
            numbers contact,
            String userEmail
    ) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                COL_CONTACT_USER_EMAIL,
                normalizeEmail(userEmail)
        );

        values.put(
                COL_CONTACT_NAME,
                contact.getName()
        );

        values.put(
                COL_CONTACT_PHONE,
                contact.getNumber()
        );

        return db.insert(
                TABLE_CONTACTS,
                null,
                values
        );
    }


    // =========================================================
    // CONTACTS: DELETE
    // =========================================================

    public boolean deleteContact(
            long contactId,
            String userEmail
    ) {

        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(
                TABLE_CONTACTS,

                COL_CONTACT_ID + "=? AND " +
                        COL_CONTACT_USER_EMAIL + "=?",

                new String[]{
                        String.valueOf(contactId),
                        normalizeEmail(userEmail)
                }
        );

        return rows > 0;
    }


    // =========================================================
    // CONTACTS: GET ALL USER CONTACTS
    // =========================================================

    public List<numbers> getContactsForUser(
            String userEmail
    ) {

        List<numbers> list =
                new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_CONTACTS,
                null,

                COL_CONTACT_USER_EMAIL + "=?",

                new String[]{
                        normalizeEmail(userEmail)
                },

                null,
                null,

                COL_CONTACT_ID + " DESC"
        );

        while (cursor.moveToNext()) {

            long id =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    COL_CONTACT_ID
                            )
                    );

            String name =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COL_CONTACT_NAME
                            )
                    );

            String phone =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COL_CONTACT_PHONE
                            )
                    );

            list.add(
                    new numbers(
                            id,
                            name,
                            phone
                    )
            );
        }

        cursor.close();

        return list;
    }


    // =========================================================
    // FETAL DEVELOPMENT: GET ONE WEEK
    // =========================================================

    @Nullable
    public FetalWeek getFetalWeek(int week) {

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_FETAL,
                null,

                COL_FETAL_WEEK + "=?",

                new String[]{
                        String.valueOf(week)
                },

                null,
                null,
                null
        );

        FetalWeek result = null;

        if (cursor.moveToFirst()) {

            result = fetalWeekFromCursor(cursor);
        }

        cursor.close();

        return result;
    }


    // =========================================================
    // FETAL DEVELOPMENT: GET ALL WEEKS
    // =========================================================

    public List<FetalWeek> getAllFetalWeeks() {

        List<FetalWeek> list =
                new ArrayList<>();

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_FETAL,
                null,
                null,
                null,
                null,
                null,
                COL_FETAL_WEEK + " ASC"
        );

        while (cursor.moveToNext()) {

            list.add(
                    fetalWeekFromCursor(cursor)
            );
        }

        cursor.close();

        return list;
    }


    // =========================================================
    // CONVERT CURSOR TO FETAL WEEK
    // =========================================================

    private FetalWeek fetalWeekFromCursor(
            Cursor cursor
    ) {

        return new FetalWeek(

                cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_WEEK
                        )
                ),

                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_TITLE
                        )
                ),

                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_DESC
                        )
                ),

                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_TIP_ONE
                        )
                ),

                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_TIP_TWO
                        )
                ),

                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                COL_FETAL_TIP_THREE
                        )
                )
        );
    }


    // =========================================================
    // INSERT WEEKS 1 TO 40
    // =========================================================

    private void seedFetalDevelopmentData(
            SQLiteDatabase db
    ) {

        for (int week = 1; week <= 40; week++) {

            String title =
                    "الأسبوع " +
                            week +
                            " من الحمل";

            String description;

            String tipOne =
                    "التزمي بمواعيد متابعة الحمل مع الطبيبة.";

            String tipTwo;

            String tipThree =
                    "لا تتناولي أي دواء دون استشارة الطبيبة.";


            // وصف تطور الجنين حسب مرحلة الحمل

            if (week <= 4) {

                description =
                        "يبدأ حساب الحمل من أول يوم في آخر دورة، ويبدأ الجسم بالاستعداد للحمل وتكوين الجنين.";

            } else if (week <= 8) {

                description =
                        "تبدأ الأعضاء الأساسية بالتكوّن، ويتطور الدماغ والقلب والأطراف تدريجياً.";

            } else if (week <= 13) {

                description =
                        "يكتمل تكوّن معظم الأعضاء الأساسية ويبدأ الجنين بالحركة داخل الرحم.";

            } else if (week <= 20) {

                description =
                        "يزداد طول الجنين ووزنه، وتتطور ملامح الوجه والسمع والحركة.";

            } else if (week <= 27) {

                description =
                        "يستمر تطور الحواس والدماغ والرئتين، وتصبح حركة الجنين أوضح.";

            } else if (week <= 36) {

                description =
                        "يزداد وزن الجنين وتتطور الرئتان والدماغ ويبدأ بالاستعداد لوضعية الولادة.";

            } else {

                description =
                        "يكون الجنين مكتمل النمو تقريباً ويستعد للولادة خلال الفترة القادمة.";
            }


            // النصيحة الثانية تختلف حسب مرحلة الحمل

            if (week <= 13) {

                tipTwo =
                        "اهتمي بالغذاء المتوازن واسألي الطبيبة عن مكملات الحمل المناسبة.";

            } else if (week <= 27) {

                tipTwo =
                        "اشربي الماء بانتظام ومارسي نشاطاً آمناً بعد موافقة الطبيبة.";

            } else {

                tipTwo =
                        "راقبي حركة الجنين وراجعي الطبيبة إذا لاحظتِ تغيراً غير معتاد.";
            }


            ContentValues values =
                    new ContentValues();

            values.put(
                    COL_FETAL_WEEK,
                    week
            );

            values.put(
                    COL_FETAL_TITLE,
                    title
            );

            values.put(
                    COL_FETAL_DESC,
                    description
            );

            values.put(
                    COL_FETAL_TIP_ONE,
                    tipOne
            );

            values.put(
                    COL_FETAL_TIP_TWO,
                    tipTwo
            );

            values.put(
                    COL_FETAL_TIP_THREE,
                    tipThree
            );

            db.insert(
                    TABLE_FETAL,
                    null,
                    values
            );
        }
    }


    // =========================================================
    // NORMALIZE EMAIL
    // =========================================================

    private String normalizeEmail(String email) {

        if (email == null) {

            return "";
        }

        return email
                .trim()
                .toLowerCase(Locale.US);
    }
}
