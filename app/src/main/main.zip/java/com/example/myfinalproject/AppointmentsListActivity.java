package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfinalproject.databinding.ActivityAppointmentsListBinding;
import com.example.myfinalproject.databinding.ActivityRegisterBinding;

public class AppointmentsListActivity extends AppCompatActivity {
    ActivityAppointmentsListBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentsListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnAddAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AppointmentsListActivity.this, AddAppointmentActivity.class);
                startActivity(intent);
            }
        });
    }
}