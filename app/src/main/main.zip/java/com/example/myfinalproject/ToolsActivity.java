package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfinalproject.databinding.ActivityToolsBinding;

public class ToolsActivity extends AppCompatActivity {

    ActivityToolsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityToolsBinding.inflate(
                getLayoutInflater()
        );

        setContentView(binding.getRoot());

        binding.vEmergencyBg.setOnClickListener(v -> {
            Intent intent = new Intent(ToolsActivity.this, EmergencyNumbersActivity.class);

            startActivity(intent);
        });

        binding.vTipsBg.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ToolsActivity.this,
                    WeeklyTipsActivity.class
            );

            startActivity(intent);
        });
    }
}