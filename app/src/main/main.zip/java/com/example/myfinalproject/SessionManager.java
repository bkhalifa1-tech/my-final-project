package com.example.myfinalproject;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREF_NAME = "user_session";
    private static final String KEY_EMAIL = "logged_email";

    private final SharedPreferences preferences;

    public SessionManager(Context context) {
        preferences = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
        );
    }

    public void saveEmail(String email) {
        preferences.edit()
                .putString(KEY_EMAIL, email)
                .apply();
    }

    public String getEmail() {
        return preferences.getString(KEY_EMAIL, null);
    }

    public boolean isLoggedIn() {
        return getEmail() != null;
    }

    public void clearSession() {
        preferences.edit().clear().apply();
    }
}
