package com.example.myfinalproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AppointmentDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_details);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }
}
