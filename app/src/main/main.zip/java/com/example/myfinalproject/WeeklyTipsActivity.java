package com.example.myfinalproject;

public class WeeklyTipsActivity {
}
