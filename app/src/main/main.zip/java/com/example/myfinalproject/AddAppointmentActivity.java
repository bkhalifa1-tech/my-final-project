package com.example.myfinalproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AddAppointmentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_appointment);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }
}
