package com.example.myfinalproject.PackdgeRecyclerNumber;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.databinding.ItemNumberBinding;

import java.util.ArrayList;

public class numberAdapter extends RecyclerView.Adapter<numberAdapter.NumberViweHolder> {
    Context context ;
ArrayList<numbers>numbers;
OnNumberActionListener actionListener;


    public numberAdapter(Context context, ArrayList<numbers> numbers ,OnNumberActionListener actionListener) {
        this.context = context;
        this.numbers = numbers;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public NumberViweHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemNumberBinding binding=ItemNumberBinding.inflate(
                LayoutInflater.from(parent.getContext()),parent,false);
        return new NumberViweHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull NumberViweHolder holder, int position) {
        numbers n=numbers.get(position);
        holder.numberNameTv.setText(n.getName());
        holder.numberPhoneTv.setText(n.getNumber());
        holder.vTphoneCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionListener.onCall(n ,holder.getBindingAdapterPosition());


            }
        });    holder.vTDeleteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionListener.onDelete(n ,holder.getBindingAdapterPosition());


            }
        });
    }

    @Override
    public int getItemCount() {
        return numbers.size();
    }

    public void notifyDataSetChanged(int size) {
    }

    public  static class  NumberViweHolder extends RecyclerView.ViewHolder {
 TextView numberPhoneTv ,numberNameTv;
 ImageView vTphoneCall ,vTDeleteIcon;
        // المسؤول عن الديزاين تبعي
        public NumberViweHolder(@NonNull ItemNumberBinding binding) {
            super(binding.getRoot());
            numberPhoneTv=binding.numberPhoneTv;
            numberNameTv=binding.numberNameTv;
            vTphoneCall=binding.vTphoneCall;
            vTDeleteIcon=binding.vTDeleteIcon;

        }
    }
}
