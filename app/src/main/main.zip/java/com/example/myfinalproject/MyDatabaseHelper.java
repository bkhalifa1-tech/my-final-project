package com.example.myfinalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.myfinalproject.PackdgeRecyclerNumber.numbers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    // اسم قاعدة البيانات وإصدارها
    private static final String DATABASE_NAME = "pregnancy.db";
    private static final int DATABASE_VERSION = 1;

    // جدول المستخدمين
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USER_NAME = "name";
    private static final String COL_USER_EMAIL = "email";
    private static final String COL_USER_PHONE = "phone";
    private static final String COL_USER_PASSWORD = "password";
    private static final String COL_USER_LAST_PERIOD = "last_period_date";
    private static final String COL_USER_DUE_DATE = "due_date";
    private static final String COL_USER_IMAGE = "profile_image_path";

    // جدول المواعيد
    private static final String TABLE_APPOINTMENTS = "appointments";
    private static final String COL_APP_ID = "id";
    private static final String COL_APP_USER_EMAIL = "user_email";
    private static final String COL_APP_SUBJECT = "subject";
    private static final String COL_APP_DOCTOR = "doctor";
    private static final String COL_APP_DATE = "app_date";
    private static final String COL_APP_TIME = "app_time";
    private static final String COL_APP_LOCATION = "location";
    private static final String COL_APP_PHONE = "phone";

    // جدول أرقام الطوارئ
    private static final String TABLE_CONTACTS = "contacts";
    private static final String COL_CONTACT_ID = "id";
    private static final String COL_CONTACT_USER_EMAIL = "user_email";
    private static final String COL_CONTACT_NAME = "name";
    private static final String COL_CONTACT_PHONE = "phone";

    // جدول أسابيع الحمل
    private static final String TABLE_WEEKS = "pregnancy_weeks";
    private static final String COL_WEEK_NUMBER = "week_number";
    private static final String COL_WEEK_SIZE = "size_label";
    private static final String COL_WEEK_DEVELOPMENT = "development";
    private static final String COL_WEEK_TIP_ONE = "tip_one";
    private static final String COL_WEEK_TIP_TWO = "tip_two";
    private static final String COL_WEEK_TIP_THREE = "tip_three";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // إنشاء جدول المستخدمين
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_NAME + " TEXT NOT NULL, " +
                COL_USER_EMAIL + " TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                COL_USER_PHONE + " TEXT NOT NULL, " +
                COL_USER_PASSWORD + " TEXT NOT NULL, " +
                COL_USER_LAST_PERIOD + " TEXT, " +
                COL_USER_DUE_DATE + " TEXT, " +
                COL_USER_IMAGE + " TEXT);";
        db.execSQL(createUsersTable);

        // إنشاء جدول المواعيد
        String createAppointmentsTable = "CREATE TABLE " + TABLE_APPOINTMENTS + " (" +
                COL_APP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_APP_USER_EMAIL + " TEXT NOT NULL, " +
                COL_APP_SUBJECT + " TEXT NOT NULL, " +
                COL_APP_DOCTOR + " TEXT, " +
                COL_APP_DATE + " TEXT, " +
                COL_APP_TIME + " TEXT, " +
                COL_APP_LOCATION + " TEXT, " +
                COL_APP_PHONE + " TEXT, " +
                "FOREIGN KEY(" + COL_APP_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_EMAIL + ") ON DELETE CASCADE);";
        db.execSQL(createAppointmentsTable);

        // إنشاء جدول أرقام الطوارئ
        String createContactsTable = "CREATE TABLE " + TABLE_CONTACTS + " (" +
                COL_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CONTACT_USER_EMAIL + " TEXT NOT NULL, " +
                COL_CONTACT_NAME + " TEXT NOT NULL, " +
                COL_CONTACT_PHONE + " TEXT NOT NULL, " +
                "FOREIGN KEY(" + COL_CONTACT_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_EMAIL + ") ON DELETE CASCADE);";
        db.execSQL(createContactsTable);

        // إنشاء جدول أسابيع الحمل
        String createWeeksTable = "CREATE TABLE " + TABLE_WEEKS + " (" +
                COL_WEEK_NUMBER + " INTEGER PRIMARY KEY, " +
                COL_WEEK_SIZE + " TEXT NOT NULL, " +
                COL_WEEK_DEVELOPMENT + " TEXT NOT NULL, " +
                COL_WEEK_TIP_ONE + " TEXT NOT NULL, " +
                COL_WEEK_TIP_TWO + " TEXT NOT NULL, " +
                COL_WEEK_TIP_THREE + " TEXT NOT NULL);";
        db.execSQL(createWeeksTable);

        seedPregnancyWeeks(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_APPOINTMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEEKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // =========================================================
    // 1. USERS
    // =========================================================

    public boolean registerUser(String name, String email, String password, String phone) {
        if (isEmailRegistered(email)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, name.trim());
        values.put(COL_USER_EMAIL, normalizeEmail(email));
        values.put(COL_USER_PASSWORD, password);
        values.put(COL_USER_PHONE, phone.trim());

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USER_EMAIL + " = ? COLLATE NOCASE";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{normalizeEmail(email)});
        boolean exists = cursor.moveToFirst();

        cursor.close();
        db.close();
        return exists;
    }

    public User checkLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USER_EMAIL + " = ? AND " + COL_USER_PASSWORD + " = ?";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{normalizeEmail(email), password});

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)));
            user.setFullName(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)));
            user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD)));
            user.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PHONE)));
            user.setLastPeriodDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_LAST_PERIOD)));
            user.setDueDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_DUE_DATE)));
        }

        cursor.close();
        db.close();
        return user;
    }

    public User getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USER_EMAIL + " = ?";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{normalizeEmail(email)});

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)));
            user.setFullName(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)));
            user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD)));
            user.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PHONE)));
            user.setLastPeriodDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_LAST_PERIOD)));
            user.setDueDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_DUE_DATE)));
        }

        cursor.close();
        db.close();
        return user;
    }

    public boolean updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, user.getFullName());
        values.put(COL_USER_PHONE, user.getPhone());
        values.put(COL_USER_LAST_PERIOD, user.getLastPeriodDate());
        values.put(COL_USER_DUE_DATE, user.getDueDate());

        int result = db.update(TABLE_USERS, values, COL_USER_EMAIL + " = ?", new String[]{normalizeEmail(user.getEmail())});
        db.close();

        return result > 0;
    }

    // =========================================================
    // 2. APPOINTMENTS
    // =========================================================

    public boolean addAppointment(Appointment appointment) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_APP_USER_EMAIL, normalizeEmail(appointment.getUserEmail()));
        values.put(COL_APP_SUBJECT, appointment.getSubject());
        values.put(COL_APP_DOCTOR, appointment.getDoctor());
        values.put(COL_APP_DATE, appointment.getDate());
        values.put(COL_APP_TIME, appointment.getTime());
        values.put(COL_APP_LOCATION, appointment.getLocation());
        values.put(COL_APP_PHONE, appointment.getPhone());

        long result = db.insert(TABLE_APPOINTMENTS, null, values);
        db.close();

        return result != -1;
    }

    public boolean updateAppointment(Appointment appointment) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_APP_SUBJECT, appointment.getSubject());
        values.put(COL_APP_DOCTOR, appointment.getDoctor());
        values.put(COL_APP_DATE, appointment.getDate());
        values.put(COL_APP_TIME, appointment.getTime());
        values.put(COL_APP_LOCATION, appointment.getLocation());
        values.put(COL_APP_PHONE, appointment.getPhone());

        int result = db.update(TABLE_APPOINTMENTS, values,
                COL_APP_ID + " = ? AND " + COL_APP_USER_EMAIL + " = ?",
                new String[]{String.valueOf(appointment.getId()), normalizeEmail(appointment.getUserEmail())});
        db.close();

        return result > 0;
    }

    public boolean deleteAppointment(long appointmentId, String userEmail) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(TABLE_APPOINTMENTS,
                COL_APP_ID + " = ? AND " + COL_APP_USER_EMAIL + " = ?",
                new String[]{String.valueOf(appointmentId), normalizeEmail(userEmail)});
        db.close();

        return result > 0;
    }

    public ArrayList<Appointment> getAppointmentsForUser(String userEmail) {
        ArrayList<Appointment> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLE_APPOINTMENTS +
                " WHERE " + COL_APP_USER_EMAIL + " = ? ORDER BY " + COL_APP_DATE + " ASC, " + COL_APP_TIME + " ASC";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{normalizeEmail(userEmail)});

        if (cursor.moveToFirst()) {
            do {
                Appointment appointment = new Appointment();
                appointment.setId((int) cursor.getLong(cursor.getColumnIndexOrThrow(COL_APP_ID)));
                appointment.setUserEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_USER_EMAIL)));
                appointment.setSubject(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_SUBJECT)));
                appointment.setDoctor(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_DOCTOR)));
                appointment.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_DATE)));
                appointment.setTime(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_TIME)));
                appointment.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_LOCATION)));
                appointment.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COL_APP_PHONE)));

                list.add(appointment);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // =========================================================
    // 3. EMERGENCY CONTACTS (numbers)
    // =========================================================

    public boolean addContact(numbers contact, String userEmail) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_CONTACT_USER_EMAIL, normalizeEmail(userEmail));
        values.put(COL_CONTACT_NAME, contact.getName());
        values.put(COL_CONTACT_PHONE, contact.getNumber());

        long result = db.insert(TABLE_CONTACTS, null, values);
        db.close();

        return result != -1;
    }

    public boolean deleteContact(long contactId, String userEmail) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(TABLE_CONTACTS,
                COL_CONTACT_ID + " = ? AND " + COL_CONTACT_USER_EMAIL + " = ?",
                new String[]{String.valueOf(contactId), normalizeEmail(userEmail)});
        db.close();

        return result > 0;
    }

    public ArrayList<numbers> getContactsForUser(String userEmail) {
        ArrayList<numbers> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS +
                " WHERE " + COL_CONTACT_USER_EMAIL + " = ? ORDER BY " + COL_CONTACT_NAME + " COLLATE NOCASE ASC";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{normalizeEmail(userEmail)});

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_CONTACT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_CONTACT_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_CONTACT_PHONE));

                list.add(new numbers(id, name, phone));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // =========================================================
    // 4. FETAL DEVELOPMENT (FetalWeek)
    // =========================================================

    public FetalWeek getFetalWeek(int weekNumber) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_WEEKS + " WHERE " + COL_WEEK_NUMBER + " = ?";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(weekNumber)});

        FetalWeek week = null;
        if (cursor.moveToFirst()) {
            week = new FetalWeek(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_WEEK_NUMBER)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_WEEK_SIZE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_WEEK_DEVELOPMENT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_WEEK_TIP_ONE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_WEEK_TIP_TWO)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_WEEK_TIP_THREE))
            );
        }

        cursor.close();
        db.close();
        return week;
    }

    // =========================================================
    // Helper Methods
    // =========================================================

    private String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.US);
    }

    private void seedPregnancyWeeks(SQLiteDatabase db) {
        for (int week = 1; week <= 40; week++) {
            String title = "الأسبوع " + week + " من الحمل";
            String description;
            String tipOne = "حافظي على مواعيد متابعة الحمل مع الطبيبة.";
            String tipTwo;
            String tipThree = "لا تتناولي أي دواء دون استشارة الطبيبة.";

            if (week <= 12) {
                description = "تبدأ الأعضاء الأساسية بالتكوّن، ويتطور الدماغ والقلب والأطراف تدريجياً.";
                tipTwo = "اهتمي بالغذاء المتوازن واسألي الطبيبة عن مكملات الحمل المناسبة.";
            } else if (week <= 27) {
                description = "يزداد طول الجنين ووزنه، وتتطور ملامح الوجه والسمع والحركة.";
                tipTwo = "اشربي الماء بانتظام ومارسي نشاطاً آمناً بعد موافقة الطبيبة.";
            } else {
                description = "يكون الجنين مكتمل النمو تقريباً ويستعد للولادة خلال الفترة القادمة.";
                tipTwo = "راقبي حركة الجنين وراجعي الطبيبة عند ملاحظة أي تغير.";
            }

            ContentValues values = new ContentValues();
            values.put(COL_WEEK_NUMBER, week);
            values.put(COL_WEEK_SIZE, title);
            values.put(COL_WEEK_DEVELOPMENT, description);
            values.put(COL_WEEK_TIP_ONE, tipOne);
            values.put(COL_WEEK_TIP_TWO, tipTwo);
            values.put(COL_WEEK_TIP_THREE, tipThree);

            db.insert(TABLE_WEEKS, null, values);
        }
    }
}
