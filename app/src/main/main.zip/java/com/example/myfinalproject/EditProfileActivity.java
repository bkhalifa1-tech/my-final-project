package com.example.myfinalproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myfinalproject.databinding.ActivityEditProfileBinding;

import android.text.Editable;
import android.text.TextWatcher;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditProfileActivity extends AppCompatActivity {
    ActivityEditProfileBinding binding;


    ActivityResultLauncher launcher=registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult()
            , new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if (o.getResultCode()== RESULT_OK){
                     Bitmap image=(Bitmap) o.getData().getExtras().get("data");
                     binding.ImProfile.setImageBitmap(image);
                    }
                }
            }
    );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityEditProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String userEmail = getIntent().getStringExtra("email");
        if (userEmail != null) {
            binding.tvEmail.setText(userEmail);
        }


        binding.etPregnancyWeek.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence weekStr, int start, int before, int count) {
                if(weekStr.toString().isEmpty()){
                    binding.tvBirthDate.setText("");
                }else {
                    String weekStart=(String) weekStr;
                    int currentWeek = Integer.parseInt(weekStart);
                    if(currentWeek>0 && currentWeek<41){
                        int weeksLeft=40-currentWeek;
                        int dayLeft=weeksLeft*7;

                        Calendar calendar= Calendar.getInstance();
                        calendar.add(Calendar.DAY_OF_YEAR,dayLeft);
                        SimpleDateFormat simpleDateFormat= new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                        String formattedDate= simpleDateFormat.format(calendar.getTime());
                        binding.tvBirthDate.setText(formattedDate);
                    } else {
                        binding.tvBirthDate.setText("أسبوع غير صالح");
                    }

                }
            }
        });
        
        binding.btnSave.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                 String Name = binding.etFullName.getText().toString();
                 String phone = binding.etPhone.getText().toString();
                 String formattedDate = binding.tvBirthDate.getText().toString();

                    if (Name.isEmpty() ||  phone.isEmpty()) {
                        Toast.makeText(EditProfileActivity.this, "يبدو أنك نسيت إدخال  بياناتك, يرجى إدخال بياناتك ", Toast.LENGTH_SHORT).show();
                        return;
                    }

                Intent intent = new Intent();
                    intent.putExtra("Name",Name);
                    intent.putExtra("phone",phone);
                    intent.putExtra("formattedDate",formattedDate);
                    setResult(RESULT_OK,intent);
                    finish();


            }
        });

        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();

            }
        });


        binding.ImProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                launcher.launch(intent);
            }
        });

    }


}
