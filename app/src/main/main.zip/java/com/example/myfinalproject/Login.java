package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myfinalproject.databinding.ActivityLoginBinding;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
   ActivityLoginBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        DatabaseHelper databaseHelper =
                DatabaseHelper.getInstance(this);

        SessionManager sessionManager =
                new SessionManager(this);

        String registeredEmail =
                getIntent().getStringExtra("registered_email");

        if (registeredEmail != null) {
            binding.edEmail.setText(registeredEmail);
        }
        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String  password= binding.edPassword.getText().toString();
                String email = binding.edEmail.getText().toString();

                if (password.isEmpty() || email.isEmpty()) {
                    Toast.makeText(Login.this, "يبدو أنك نسيت إدخال البريد الإلكتروني وكلمة المرور. يرجى إدخال بياناتك للمتابعة", Toast.LENGTH_SHORT).show();
                    return;
                }  if ( email.isEmpty()) {
                    Toast.makeText(Login.this, "يرجى إدخال [البريد الإلكتروني] الخاص بك لتسجيل الدخول", Toast.LENGTH_SHORT).show();
                    return;
                }  if (password.isEmpty() ) {
                    Toast.makeText(Login.this, "حقل [كلمة المرور] فارغ، يرجى إدخال كلمة المرور الصحيحة", Toast.LENGTH_SHORT).show();
                    return;
                } if (password.length()<6 ) {
                    Toast.makeText(Login.this, " يرجى إدخال كلمة المرور صحيحة", Toast.LENGTH_SHORT).show();
                    return;
                }if (!email.contains("@")) {
                    Toast.makeText(Login.this, " يرجى إدخال البريد الإلكتروني صحيح", Toast.LENGTH_SHORT).show();
                    return;
                }
                User user = databaseHelper.checkLogin(
                        email,
                        password
                );

                if (user == null) {
                    Toast.makeText(
                            Login.this,
                            "البريد الإلكتروني أو كلمة المرور غير صحيحة",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                sessionManager.saveEmail(user.getEmail());

                Intent intent;

                if (user.getDueDate() == null ||
                        user.getDueDate().isEmpty()) {

                    intent = new Intent(
                            Login.this,
                            DueDateCalculatorActivity.class
                    );

                } else {

                    intent = new Intent(
                            Login.this,
                            HomeActivity.class
                    );
                }

                startActivity(intent);
                finish();


            }
        });

        binding.tvCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Login.this, Register.class);
                startActivity(intent);

            }
        });



    }
}