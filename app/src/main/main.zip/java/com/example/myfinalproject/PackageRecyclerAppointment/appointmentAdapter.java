package com.example.myfinalproject.PackageRecyclerAppointment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinalproject.databinding.ItemAppointmentBinding;

import java.util.ArrayList;

public class appointmentAdapter extends RecyclerView.Adapter<appointmentAdapter.appointmentViweHolder> {
    ArrayList<appointments>appointments;

    @NonNull
    @Override
    public appointmentViweHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemAppointmentBinding binding=ItemAppointmentBinding.inflate(
                LayoutInflater.from(parent.getContext()),parent,false
        );
        return new appointmentViweHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull appointmentViweHolder holder, int position) {
        appointments a =appointments.get(position);
        holder.tvItemTime.setText(a.getTime());
        holder.tvItemTitle.setText(a.getSubject());
    }

    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public static class appointmentViweHolder extends RecyclerView.ViewHolder{
TextView tvItemTitle,tvItemTime;
        public appointmentViweHolder(@NonNull ItemAppointmentBinding binding) {
            super(binding.getRoot());
            tvItemTime=binding.tvItemTime;
            tvItemTitle=binding.tvItemTitle;
        }
    }
}
