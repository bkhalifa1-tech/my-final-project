package com.example.myfinalproject.PackdgeRecyclerNumber;

public interface OnNumberActionListener {

    void onDelete(numbers item ,int position);
    void onCall(numbers item ,int position);
}
