package com.example.myfinalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.applandeo.materialcalendarview.CalendarDay;
import com.example.myfinalproject.databinding.ActivityDueDateCalculatorBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DueDateCalculatorActivity extends AppCompatActivity {

    private ActivityDueDateCalculatorBinding binding;

    private DatabaseHelper databaseHelper;
    private SessionManager sessionManager;

    // التاريخ الذي تختاره المستخدمة كآخر دورة شهرية
    private Calendar selectedLastPeriodDate;

    // لمعرفة هل تم حساب موعد الولادة أم لا
    private boolean calculationCompleted = false;

    // موعد الولادة المحفوظ بصيغة yyyy-MM-dd
    private String calculatedDueDate;

    // مفاتيح حفظ البيانات عند تدوير الشاشة
    private static final String STATE_LAST_PERIOD =
            "state_last_period";

    private static final String STATE_CALCULATION_COMPLETED =
            "state_calculation_completed";

    private static final String STATE_DUE_DATE =
            "state_due_date";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDueDateCalculatorBinding.inflate(
                getLayoutInflater()
        );

        setContentView(binding.getRoot());

        // إنشاء كائنات قاعدة البيانات والجلسة
        databaseHelper = DatabaseHelper.getInstance(
                DueDateCalculatorActivity.this
        );

        sessionManager = new SessionManager(
                DueDateCalculatorActivity.this
        );

        // إخفاء نتيجة الولادة في البداية
        hideResult();

        // استرجاع البيانات إذا تم تدوير الشاشة
        restoreSavedState(savedInstanceState);

        /*
         * عند اختيار يوم من التقويم:
         * نخزنه على أنه تاريخ آخر دورة شهرية.
         */
        binding.calendarView.setOnCalendarDayClickListener(
                calendarDay -> {

                    selectedLastPeriodDate =
                            (Calendar) calendarDay
                                    .getCalendar()
                                    .clone();

                    /*
                     * إذا غيرت المستخدمة التاريخ بعد إجراء الحساب،
                     * نعيد الزر إلى وضع الحساب.
                     */
                    calculationCompleted = false;
                    calculatedDueDate = null;

                    hideResult();

                    binding.btnCalcAction.setText(
                            "حساب موعد الولادة"
                    );
                }
        );

        binding.btnCalcAction.setOnClickListener(view -> {

            /*
             * إذا كان الحساب قد تم مسبقاً،
             * يصبح الزر للانتقال إلى الشاشة الرئيسية.
             */
            if (calculationCompleted) {
                openHomeActivity();
                return;
            }

            calculateAndSaveDueDate();
        });
    }

    /*
     * حساب موعد الولادة وحفظه داخل SQLite.
     */
    private void calculateAndSaveDueDate() {

        // التأكد من اختيار تاريخ آخر دورة
        if (selectedLastPeriodDate == null) {

            Toast.makeText(
                    DueDateCalculatorActivity.this,
                    "الرجاء اختيار تاريخ آخر دورة أولاً",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // الحصول على بريد المستخدمة المسجلة
        String email = sessionManager.getEmail();

        if (email == null || email.trim().isEmpty()) {

            Toast.makeText(
                    DueDateCalculatorActivity.this,
                    "لم يتم العثور على جلسة تسجيل الدخول",
                    Toast.LENGTH_SHORT
            ).show();

            openLoginActivity();
            return;
        }

        // جلب المستخدم من قاعدة البيانات
        User user = databaseHelper.getUserByEmail(email);

        if (user == null) {

            Toast.makeText(
                    DueDateCalculatorActivity.this,
                    "لم يتم العثور على حساب المستخدم",
                    Toast.LENGTH_SHORT
            ).show();

            sessionManager.clearSession();
            openLoginActivity();
            return;
        }

        /*
         * موعد الولادة المتوقع يساوي:
         * تاريخ أول يوم من آخر دورة + 280 يوماً.
         */
        Calendar dueDateCalendar =
                (Calendar) selectedLastPeriodDate.clone();

        dueDateCalendar.add(
                Calendar.DAY_OF_YEAR,
                280
        );

        // صيغة موحدة لحفظ التاريخ في SQLite
        SimpleDateFormat storageDateFormat =
                new SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.US
                );

        String lastPeriodDate =
                storageDateFormat.format(
                        selectedLastPeriodDate.getTime()
                );

        calculatedDueDate =
                storageDateFormat.format(
                        dueDateCalendar.getTime()
                );

        // وضع التواريخ داخل كائن المستخدم
        user.setLastPeriodDate(lastPeriodDate);
        user.setDueDate(calculatedDueDate);

        // تحديث بيانات المستخدم داخل SQLite
        boolean updated =
                databaseHelper.updateUser(user);

        if (!updated) {

            Toast.makeText(
                    DueDateCalculatorActivity.this,
                    "حدث خطأ أثناء حفظ موعد الولادة",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // إظهار النتيجة للمستخدمة
        showResult(calculatedDueDate);

        calculationCompleted = true;

        // يتحول الزر إلى زر متابعة
        binding.btnCalcAction.setText(
                "متابعة إلى الرئيسية"
        );

        Toast.makeText(
                DueDateCalculatorActivity.this,
                "تم حفظ موعد الولادة بنجاح",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * إظهار مربع نتيجة موعد الولادة.
     */
    private void showResult(String dueDate) {

        binding.vResultBg.setVisibility(View.VISIBLE);
        binding.tvResultLabel.setVisibility(View.VISIBLE);
        binding.tvResultValue.setVisibility(View.VISIBLE);

        binding.tvResultValue.setText(dueDate);
    }

    /*
     * إخفاء مربع النتيجة.
     */
    private void hideResult() {

        binding.vResultBg.setVisibility(View.GONE);
        binding.tvResultLabel.setVisibility(View.GONE);
        binding.tvResultValue.setVisibility(View.GONE);
    }

    /*
     * الانتقال إلى الشاشة الرئيسية.
     */
    private void openHomeActivity() {

        Intent intent = new Intent(
                DueDateCalculatorActivity.this,
                HomeActivity.class
        );

        startActivity(intent);

        // منع الرجوع إلى شاشة حساب الولادة
        finish();
    }

    /*
     * الرجوع إلى تسجيل الدخول إذا لم توجد جلسة مستخدم.
     */
    private void openLoginActivity() {

        Intent intent = new Intent(
                DueDateCalculatorActivity.this,
                Login.class
        );

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(intent);
        finish();
    }

    /*
     * حفظ البيانات عند تدوير الشاشة.
     */
    @Override
    protected void onSaveInstanceState(
            @NonNull Bundle outState
    ) {

        super.onSaveInstanceState(outState);

        if (selectedLastPeriodDate != null) {

            outState.putLong(
                    STATE_LAST_PERIOD,
                    selectedLastPeriodDate.getTimeInMillis()
            );
        }

        outState.putBoolean(
                STATE_CALCULATION_COMPLETED,
                calculationCompleted
        );

        outState.putString(
                STATE_DUE_DATE,
                calculatedDueDate
        );
    }

    /*
     * استرجاع البيانات بعد تدوير الشاشة.
     */
    private void restoreSavedState(
            Bundle savedInstanceState
    ) {

        if (savedInstanceState == null) {
            return;
        }

        if (savedInstanceState.containsKey(
                STATE_LAST_PERIOD
        )) {

            selectedLastPeriodDate =
                    Calendar.getInstance();

            selectedLastPeriodDate.setTimeInMillis(
                    savedInstanceState.getLong(
                            STATE_LAST_PERIOD
                    )
            );
        }

        calculationCompleted =
                savedInstanceState.getBoolean(
                        STATE_CALCULATION_COMPLETED,
                        false
                );

        calculatedDueDate =
                savedInstanceState.getString(
                        STATE_DUE_DATE
                );

        if (calculationCompleted &&
                calculatedDueDate != null) {

            showResult(calculatedDueDate);

            binding.btnCalcAction.setText(
                    "متابعة إلى الرئيسية"
            );
        }
    }
}
